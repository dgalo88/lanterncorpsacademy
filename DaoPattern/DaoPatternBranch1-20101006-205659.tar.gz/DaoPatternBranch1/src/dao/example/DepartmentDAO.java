package dao.example;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dao.api.BaseDAO;
import dao.api.ColumnDescriptor;
import dao.api.DataObject;
import dao.api.FactoryDAO;
import dao.api.InterfaceDAO;
import dao.api.Reference;
import dao.api.ReferenceList;
import dao.reflection.PropertyUtil;

/**
 * @author Demián Gutierrez
 */
public class DepartmentDAO extends BaseDAO {

  public DepartmentDAO() {
    super(DepartmentDO.class);
  }

  // --------------------------------------------------------------------------------

  public void createTable() throws SQLException {
    StringBuffer strbuf;

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("DROP TABLE IF EXISTS ");
    strbuf.append(getTableName());
    strbuf.append(" CASCADE");

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("DROP SEQUENCE IF EXISTS ");
    strbuf.append("seq_");
    strbuf.append(getTableName());

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("CREATE TABLE ");
    strbuf.append(getTableName());
    strbuf.append(" (");
    strbuf.append(DepartmentDO.ID);
    strbuf.append(" INT PRIMARY KEY, ");
    strbuf.append(DepartmentDO.NAME);
    strbuf.append(" VARCHAR(100),    ");
    strbuf.append(DepartmentDO.DESCRIPTION);
    strbuf.append(" VARCHAR(100)     ");
    strbuf.append(")");

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("CREATE SEQUENCE ");
    strbuf.append("seq_");
    strbuf.append(getTableName());

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());
  }

  // --------------------------------------------------------------------------------

  public void loadEmployeeList(DepartmentDO departmentDO) throws Exception {
    checkCache(departmentDO, CHECK_UPDATE);
    //checkClass(departmentDO, DepartmentDO.class, CHECK_UPDATE);

    InterfaceDAO interfaceDAO = (InterfaceDAO) FactoryDAO.getDAO( //
        EmployeeDAO.class, connectionBean);

    departmentDO.setEmployeeList(employeeDAO.listByDepartmentId(departmentDO.getId()));
  }


  // --------------------------------------------------------------------------------

  public List<DepartmentDO> listByNameAndLikeDescription(String name, String description) throws Exception {
    StringBuffer strbuf = new StringBuffer();

    strbuf.append("SELECT * FROM ");
    strbuf.append(getTableName());

    strbuf.append(" WHERE ");
    strbuf.append(DepartmentDO.NAME);
    strbuf.append(" = ");
    strbuf.append(singleQuotes(name));

    strbuf.append(" AND ");
    strbuf.append(DepartmentDO.DESCRIPTION);
    strbuf.append(" LIKE ");
    strbuf.append(singleQuotes("%" + description + "%"));

    System.err.println(strbuf.toString());

    ResultSet rs = //
    connection.createStatement().executeQuery(strbuf.toString());

    List<DepartmentDO> ret = new ArrayList<DepartmentDO>();

    while (rs.next()) {
      ret.add((DepartmentDO) resultSetToDO(rs));
    }

    return ret;
  }
}
