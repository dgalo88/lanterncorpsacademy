package dao.example;

import dao.annotation.OneToMany;
import dao.annotation.PK;
import dao.annotation.Type;
import dao.api.DataObject;
import dao.api.ReferenceList;

/**
 * @author Demián Gutierrez
 */
public class DepartmentDO implements DataObject {

  public static final String NAME/*    */= "name";
  public static final String DESCRIPTION = "description";

  // --------------------------------------------------------------------------------

  private int id;

  private String name;
  private String description;

  // --------------------------------------------------------------------------------

  private ReferenceList<EmployeeDO> employeeList = //
  new ReferenceList<EmployeeDO>(DepartmentDO.class, "employeeList");

  // --------------------------------------------------------------------------------

  public DepartmentDO() throws Exception {
    // Empty
  }

  // --------------------------------------------------------------------------------

  @PK
  @Type("INT")
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  // --------------------------------------------------------------------------------

  @Type("VARCHAR(100)")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // --------------------------------------------------------------------------------

  @Type("VARCHAR(100)")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  // --------------------------------------------------------------------------------

  @OneToMany(mappedBy = "departmentRef", daoClass = EmployeeDAO.class)
  public ReferenceList<EmployeeDO> getEmployeeList() {
    return employeeList;
  }

  public void setEmployeeList(ReferenceList<EmployeeDO> employeeList) {
    this.employeeList = employeeList;
  }
}
