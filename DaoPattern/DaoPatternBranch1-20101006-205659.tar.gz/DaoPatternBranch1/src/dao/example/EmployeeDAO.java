package dao.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.api.BaseDAO;
import dao.api.Reference;
import dao.api.ReferenceList;

/**
 * @author Demián Gutierrez
 */
public class EmployeeDAO extends BaseDAO {

  public EmployeeDAO() {
    super(EmployeeDO.class);
  }

  public void createTable() throws SQLException {
    StringBuffer strbuf;

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("DROP TABLE IF EXISTS ");
    strbuf.append(getTableName());
    strbuf.append(" CASCADE");

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("DROP SEQUENCE IF EXISTS ");
    strbuf.append("seq_");
    strbuf.append(getTableName());

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    DepartmentDAO departmentDAO = new DepartmentDAO(); // Used to make the FK
    departmentDAO.init(connectionBean);

    strbuf = new StringBuffer();

    strbuf.append("CREATE TABLE ");
    strbuf.append(getTableName());
    strbuf.append(" (");
    strbuf.append(EmployeeDO.ID);
    strbuf.append(" INT PRIMARY KEY, ");
    strbuf.append(EmployeeDO.FRST_NAME);
    strbuf.append(" VARCHAR(100),    ");
    strbuf.append(EmployeeDO.LAST_NAME);
    strbuf.append(" VARCHAR(100),    ");
    strbuf.append(EmployeeDO.DEPARTMENT_REF);
    strbuf.append(" INT REFERENCES   ");
    strbuf.append(departmentDAO.getTableName());
    strbuf.append(")");

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());

    // ----------------------------------------

    strbuf = new StringBuffer();

    strbuf.append("CREATE SEQUENCE ");
    strbuf.append("seq_");
    strbuf.append(getTableName());

    System.err.println(strbuf.toString());

    connection.createStatement().execute(strbuf.toString());
  }

  // --------------------------------------------------------------------------------

  public void loadDepartmentRef(EmployeeDO employeeDO) throws Exception {
    // XXX: Check this method's semantic
    checkClass(employeeDO, EmployeeDO.class, CHECK_UPDATE);

    DepartmentDAO departmentDAO = new DepartmentDAO();
    departmentDAO.init(connectionBean);

    Reference<DepartmentDO> ref = employeeDO.getDepartmentRef();

    // ----------------------------------------
    // If ident == 0 there is nothing to do
    // ----------------------------------------

    if (ref.getRefIdent() == 0) {
      return;
    }

    DepartmentDO departmentDO = //
    (DepartmentDO) departmentDAO.loadById(ref.getRefIdent());

    ref.setRefValue(departmentDO);
  }

  // --------------------------------------------------------------------------------

  public ReferenceList<EmployeeDO> listByDepartmentId(int departmentId) throws Exception {
    StringBuffer strbuf = new StringBuffer();

    strbuf.append("SELECT * FROM ");
    strbuf.append(getTableName());

    strbuf.append(" WHERE ");
    strbuf.append(EmployeeDO.DEPARTMENT_REF);
    strbuf.append(" = ");
    strbuf.append(departmentId);

    System.err.println(strbuf.toString());

    ResultSet rs = //
    connection.createStatement().executeQuery(strbuf.toString());

    ReferenceList<EmployeeDO> ret = new ReferenceList<EmployeeDO>();

    while (rs.next()) {
      ret.add((EmployeeDO) resultSetToDO(rs));
    }

    return ret;
  }
}
