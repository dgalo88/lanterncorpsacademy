package dao.annotation;

public @interface Transient {

}
