package dao.reflection;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dao.api.ColumnDescriptor;
import dao.example.DepartmentDO;

public class PropertyUtil {

  public static List<ColumnDescriptor> getColumnDescriptorList(Object object) {
    Map<String, ColumnDescriptor> columnDescriptorMap = //
    new HashMap<String, ColumnDescriptor>();

    Set<String> getterPropertySet = new HashSet<String>();
    Set<String> setterPropertySet = new HashSet<String>();

    Class<?> clazz = object.getClass();

    Method[] methodArray = clazz.getMethods();

    for (Method method : methodArray) {
      
      System.out.println(method.getName());
      if (!method.getName().startsWith("get") && //
          !method.getName().startsWith("set")) {
        continue;
      }

      String property = method.getName().substring(3);

      if (property.length() == 0) {
        continue;
      }

      property = //
      Character.toLowerCase(property.charAt(0)) + //
          property.substring(1);

      if (method.getName().startsWith("get")) {
        getterPropertySet.add(property);

        columnDescriptorMap.put(property, //
            new ColumnDescriptor(method.getReturnType(), property));
      } else {
        setterPropertySet.add(property);
      }
    }

    Iterator<Map.Entry<String, ColumnDescriptor>> itt = //
    columnDescriptorMap.entrySet().iterator();

    while (itt.hasNext()) {
      Map.Entry<String, ColumnDescriptor> entry = itt.next();

      if (!getterPropertySet.contains(entry.getKey()) || //
          !setterPropertySet.contains(entry.getKey())) {
        itt.remove();
      }
    }

    return new ArrayList<ColumnDescriptor>(columnDescriptorMap.values());
  }

  // --------------------------------------------------------------------------------

  private static String getGetterName(String property) {
    property = //
    Character.toUpperCase(property.charAt(0)) + //
        property.substring(1);
    return "get" + property;
  }

  // --------------------------------------------------------------------------------

  private static String getSetterName(String property) {
    property = //
    Character.toUpperCase(property.charAt(0)) + //
        property.substring(1);
    return "set" + property;
  }

  // --------------------------------------------------------------------------------

  public static Object/**/callGet(Object thiz, String property) //
      throws Exception {

    Class<?> clazzThi = thiz.getClass();

    Method getMethod = clazzThi.getMethod(getGetterName(property), new Class<?>[]{});
    return getMethod.invoke(thiz, new Object[0]);
  }

  // --------------------------------------------------------------------------------

  public static void/*  */callSet(Object thiz, String property, Object value) //
      throws Exception {

    Class<?> clazzThi = thiz.getClass();

    Method getMethod = clazzThi.getMethod(getGetterName(property), new Class<?>[]{});
    Class<?> clazzRet = getMethod.getReturnType();

    Method setMethod = clazzThi.getMethod(getSetterName(property), new Class<?>[]{clazzRet});
    setMethod.invoke(thiz, new Object[]{value});
  }

  public static void main(String[] args) throws Exception {
    DepartmentDO d = new DepartmentDO();

    List<ColumnDescriptor> list = getColumnDescriptorList(d);

    for (ColumnDescriptor columnDescriptor : list) {
      System.err.println(columnDescriptor.getName() + ";" + //
          columnDescriptor.getType());

    }
  }
}
