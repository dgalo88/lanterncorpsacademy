package dao.api;

import java.lang.reflect.Method;
import java.util.List;

import dao.annotation.OneToMany;

public class ReferenceList<Ref extends DataObject> {

  protected OneToMany oneToMany;

  protected List<Ref> list;

  // --------------------------------------------------------------------------------

  public ReferenceList(Class<? extends DataObject> clazz, String property) //
      throws Exception {

    property = property.substring(0, 1).toUpperCase() + //
        property.substring(1);

    Method method = //
    clazz.getMethod("get" + property, new Class<?>[]{});

    oneToMany = method.getAnnotation(OneToMany.class);

    if (oneToMany == null) {
      throw new NullPointerException("oneToMany == null: " + //
          clazz.getName() + "; " + property);
    }
  }

  // --------------------------------------------------------------------------------

  public OneToMany getOneToMany() {
    return oneToMany;
  }

  // --------------------------------------------------------------------------------

  public List<Ref> getList() {
    return list;
  }
}
