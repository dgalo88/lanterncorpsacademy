package dao.api;

import java.sql.SQLException;
import java.util.List;

import dao.connection.ConnectionBean;

/**
 * @author Hugo Morillo
 */
public interface InterfaceDAO {

  public void init(ConnectionBean connectionBean);

  // --------------------------------------------------------------------------------

  public void createTable() throws SQLException;

  // --------------------------------------------------------------------------------

  public void insert(DataObject bean) throws Exception;

  public void update(DataObject bean) throws Exception;

  public void delete(DataObject bean) throws Exception;

  // --------------------------------------------------------------------------------

  public DataObject loadById(int id) throws Exception;

  // --------------------------------------------------------------------------------

  public List<DataObject> listAll(int lim, int off) throws Exception;

  public List<DataObject> listAll() throws Exception;

  public int countAll() throws Exception;

  // --------------------------------------------------------------------------------

  public void loadReferenceListList( //
      ReferenceList<DataObject> referenceList, //
      DataObject dataObject) throws Exception;

  // --------------------------------------------------------------------------------

  public List<DataObject> listByProperty( //
      String property, Object value) throws Exception;

  // --------------------------------------------------------------------------------

  public String getTableName();
}
