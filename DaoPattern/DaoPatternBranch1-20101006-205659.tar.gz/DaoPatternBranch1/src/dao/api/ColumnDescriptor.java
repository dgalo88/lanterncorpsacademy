package dao.api;

public class ColumnDescriptor {

  protected Class<?>/**/type;

  protected String/*  */name;

  // --------------------------------------------------------------------------------

  public ColumnDescriptor(Class<?> type, String name) {
    this.name = name;
    this.type = type;
  }

  // --------------------------------------------------------------------------------

  public Class<?>/**/getType() {
    return type;
  }

  public String/*  */getName() {
    return name;
  }
}
